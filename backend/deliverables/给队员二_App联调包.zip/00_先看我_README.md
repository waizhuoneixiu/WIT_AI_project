# 📦 给队员二：App 联调包 —— 先看我

你好！这是钢见项目后端的**接口联调包**。你不需要电脑上装模型/训练环境，只需要：

1. 拿到 **服务地址** 和 **临时 API Key**（队长私聊给你，形如 `http://192.168.1.20:8000`、`steel-ai-demo-2026`）；
2. 用包里的 `06_测试连接.py` 先自测一次（30 秒）；
3. 按 `01_队友API调用文档.md` 和 `03_接口速查卡.md` 接 App。

---

## 第一步：30 秒自测

```powershell
pip install requests
python 06_测试连接.py --base http://192.168.x.x:8000 --key steel-ai-demo-2026 --image samples/patches_110.jpg
```

看到 `全部连通 ✔` 就说明网络、鉴权、检测接口都正常。

**常见失败原因**：
| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 连接超时 | 手机/电脑不在同一 Wi-Fi | 连同一个 Wi-Fi，找队长要穿透地址 |
| 401 | Key 不对 | 找队长确认 `STEELSCAN_API_KEY` |
| 400 | 图片打不开 | 换 jpg/png，确认文件不是 0 字节 |
| 422 | 字段名不对 | 单图字段必须是 `image` |

---

## 第二步：看文档

| 文件 | 用途 |
| --- | --- |
| `01_队友API调用文档.md` | 必看：接口清单、鉴权、Python 示例、错误码 |
| `02_API接口文档.md` | 完整字段说明（写页面/报告时查） |
| `03_接口速查卡.md` | 一页版：App 主流程 + class_id + 状态/错误码 |
| `04_openapi.json` | 导入 Postman / Apifox / Swagger 自动生成客户端 |
| `05_接口调用示例.py` | 可直接运行的 Python 示例 |
| `samples/` | 真实接口响应 JSON（可先拿它写界面，不用等后端） |
| `内网穿透联调步骤.md` | 需要远程联调时看（cpolar/ngrok） |

---

## App 主流程（必须记住）

```
① POST /api/inspections（image + batch_no）→ 拿到 inspection_id、task_id
② GET /api/inspections/{id} 或 WS /ws/tasks/{task_id} → 拿检测框
③ POST /api/inspections/{id}/analysis → 大模型复检建议
④ POST /api/chat/messages → 追问
⑤ POST /api/inspections/{id}/review → 人工复核（base_version 防覆盖，冲突返回 409）
⑥ GET /api/batches/{batch_no}/summary → 批次统计
⑦ GET /api/reports/{inspection_id} → Markdown 报告
```

- class_id：`0 龟裂、1 夹杂、2 斑块、3 麻点、4 轧入氧化皮、5 划痕`
- `bbox_xyxy` 是**原图像素坐标**，按原图宽高等比缩放画框
- 检测完成 ≠ 人工确认；状态和复核状态是两回事
- 所有 `/api` 接口都要带请求头：`X-API-Key: <Key>`
- 详细示例见文档，有问题把请求/响应发到群里，队长直接改

---

## 注意

- 这个包**不含任何密钥**；Key 只在队长那里，演示结束会更换；
- 不要把 Key 写进 App 源码、提交到 Git、或发到公开群；
- 手机连电脑时，Windows 防火墙要放行 8000 端口（队长会处理）。
