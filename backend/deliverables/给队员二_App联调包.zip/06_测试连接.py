# -*- coding: utf-8 -*-
"""30 秒自测：检查服务地址、API Key、检测接口是否连通。

用法：
    python 06_测试连接.py --base http://192.168.1.20:8000 --key steel-ai-demo-2026
    python 06_测试连接.py --base https://xxx.cpolar.cn --key xxx --image samples/patches_110.jpg
"""
import argparse
import json
import os
import sys

import requests

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', default=os.environ.get('STEELSCAN_BASE', ''), help='服务地址，如 http://192.168.1.20:8000')
    ap.add_argument('--key', default=os.environ.get('STEELSCAN_API_KEY', ''), help='临时 API Key')
    ap.add_argument('--image', default=os.path.join(HERE, 'samples', 'patches_110.jpg'), help='测试图片路径')
    args = ap.parse_args()
    if not args.base:
        print('请先填写 --base（服务地址），例如：http://192.168.1.20:8000')
        return 1
    base = args.base.rstrip('/')
    headers = {'X-API-Key': args.key} if args.key else {}

    print('1) /health ...')
    try:
        h = requests.get(base + '/health', timeout=10).json()
    except Exception as e:  # noqa: BLE001
        print('   [FAIL] 连不上服务：', e)
        print('   检查：手机/电脑同一 Wi-Fi、地址端口、防火墙')
        return 1
    print('   [OK]', h.get('status'), '| auth_required=', h.get('auth_required'), '| version=', h.get('version'))

    print('2) /classes ...')
    c = requests.get(base + '/classes', timeout=10).json()['classes']
    print('   [OK] 类别数:', len(c), '| 顺序:', [x['name'] for x in c])

    print('3) POST /api/inspections（上传示例图） ...')
    if not os.path.exists(args.image):
        print('   [FAIL] 找不到测试图片:', args.image)
        return 1
    with open(args.image, 'rb') as f:
        r = requests.post(base + '/api/inspections', headers=headers,
                          files={'image': (os.path.basename(args.image), f, 'image/jpeg')},
                          data={'batch_no': 'CONNECT-TEST-001'}, timeout=120)
    if r.status_code == 401:
        print('   [FAIL] 401：Key 不对或没带。找队长确认临时 Key')
        return 1
    if r.status_code >= 400:
        print('   [FAIL] HTTP', r.status_code, r.text[:200])
        return 1
    created = r.json()
    print('   [OK] inspection_id =', created.get('inspection_id'))
    print('        task_id       =', created.get('task_id'))
    print('        检出缺陷数     =', created.get('detection_count'))
    print('        图片尺寸       =', created.get('image_width'), 'x', created.get('image_height'))
    print('        时延           =', created.get('timing'))

    print('4) GET /api/inspections/{id} ...')
    detail = requests.get(base + '/api/inspections/' + created['inspection_id'], headers=headers, timeout=30).json()
    for d in detail.get('detections', []):
        print('   [OK]', d['class_name'], d.get('class_cn', ''), d['score'], d['bbox_xyxy'])
    print('\n全部连通 ✔  可以把结果截图发群里；接下来看 01_队友API调用文档.md 接 App。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
